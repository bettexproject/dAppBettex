module.exports = {
    subevents: {
        1: 't1',
        2: 't2',
        3: 'draw',
    },
};
